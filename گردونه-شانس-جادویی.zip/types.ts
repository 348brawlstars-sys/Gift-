export interface Prize {
  id: number;
  label: string;
  color: string;
  weight: number; // 1 to 100
}

export interface SpinResult {
  prize: Prize;
  winningIndex: number;
}
