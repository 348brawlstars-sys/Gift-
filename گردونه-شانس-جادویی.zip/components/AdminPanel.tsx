import React, { useState } from 'react';
import { Prize } from '../types';
import { ADMIN_PASSWORD } from '../constants';
import { X, Lock, Save, RotateCcw } from 'lucide-react';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  prizes: Prize[];
  onUpdatePrizes: (prizes: Prize[]) => void;
  onResetCooldown: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ isOpen, onClose, prizes, onUpdatePrizes, onResetCooldown }) => {
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [localPrizes, setLocalPrizes] = useState<Prize[]>(prizes);

  if (!isOpen) return null;

  const handleLogin = () => {
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      // Update local state with current props when opening
      setLocalPrizes(prizes);
    } else {
      alert('کصکش رمز اشتباهه فقط رئیس می‌تونه وارد شه');
    }
  };

  const handleWeightChange = (id: number, val: string) => {
    const newWeight = parseInt(val, 10);
    if (isNaN(newWeight) || newWeight < 0) return;
    
    setLocalPrizes(prev => prev.map(p => 
      p.id === id ? { ...p, weight: newWeight } : p
    ));
  };

  const saveChanges = () => {
    onUpdatePrizes(localPrizes);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-gray-900 border border-gray-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-gray-800 bg-gray-800/50">
          <h2 className="text-xl font-bold flex items-center gap-2 text-white">
            <Lock size={20} className="text-yellow-500" />
            پنل مدیریت
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {!isAuthenticated ? (
            <div className="flex flex-col items-center gap-4 py-8">
              <p className="text-gray-400">لطفا رمز عبور مدیریت را وارد کنید:</p>
              <input 
                type="password" 
                className="bg-gray-800 border border-gray-600 text-white px-4 py-2 rounded-lg text-center text-lg tracking-widest focus:outline-none focus:border-blue-500 w-64"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="****"
              />
              <button 
                onClick={handleLogin}
                className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-lg font-bold transition-all"
              >
                ورود
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              
              <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700">
                 <div className="flex justify-between items-center mb-4">
                   <h3 className="font-bold text-lg text-blue-400">تنظیم شانس برنده شدن</h3>
                   <span className="text-xs text-gray-500">(اعداد بزرگتر = شانس بیشتر)</span>
                 </div>
                 
                 <div className="space-y-3">
                   {localPrizes.map((prize) => (
                     <div key={prize.id} className="flex items-center gap-4 bg-gray-900 p-3 rounded-lg">
                       <div className="w-4 h-4 rounded-full shadow-lg" style={{ backgroundColor: prize.color }}></div>
                       <span className="flex-1 text-sm md:text-base truncate" title={prize.label}>{prize.label}</span>
                       <div className="flex items-center gap-2">
                         <span className="text-xs text-gray-500">شانس:</span>
                         <input 
                            type="number" 
                            min="0" 
                            max="1000"
                            value={prize.weight}
                            onChange={(e) => handleWeightChange(prize.id, e.target.value)}
                            className="w-20 bg-gray-800 border border-gray-600 rounded px-2 py-1 text-center focus:border-blue-500 outline-none"
                         />
                       </div>
                     </div>
                   ))}
                 </div>
              </div>

              <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700 flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-white">ریست کردن تایمر</h3>
                    <p className="text-xs text-gray-400">برای تست، تایمر 24 ساعته خود را صفر کنید</p>
                  </div>
                  <button 
                    onClick={() => { onResetCooldown(); alert('تایمر شما ریست شد'); }}
                    className="flex items-center gap-2 bg-red-600/20 hover:bg-red-600/40 text-red-400 px-4 py-2 rounded-lg transition-colors border border-red-600/30"
                  >
                    <RotateCcw size={16} />
                    ریست تایمر
                  </button>
              </div>

            </div>
          )}
        </div>

        {/* Footer Actions */}
        {isAuthenticated && (
          <div className="p-4 border-t border-gray-800 bg-gray-800/50 flex justify-end gap-3">
            <button onClick={onClose} className="px-4 py-2 text-gray-400 hover:text-white">انصراف</button>
            <button 
              onClick={saveChanges}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white px-6 py-2 rounded-lg font-bold shadow-lg shadow-green-600/20 transition-all"
            >
              <Save size={18} />
              ذخیره تغییرات
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;