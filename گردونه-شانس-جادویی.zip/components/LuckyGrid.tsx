import React, { useState, useEffect, useRef } from 'react';
import { Prize } from '../types';
import { Sparkles } from 'lucide-react';
import Countdown from './Countdown';

interface LuckyGridProps {
  prizes: Prize[];
  isSpinning: boolean;
  winnerIndex: number | null;
  onSpinComplete: () => void;
  canSpin: boolean;
  onSpinClick: () => void;
  cooldownTime: number;
  onCooldownComplete: () => void;
}

const LuckyGrid: React.FC<LuckyGridProps> = ({
  prizes,
  isSpinning,
  winnerIndex,
  onSpinComplete,
  canSpin,
  onSpinClick,
  cooldownTime,
  onCooldownComplete
}) => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  // Keep the latest version of the callback available to the timeout closure
  const onSpinCompleteRef = useRef(onSpinComplete);
  useEffect(() => {
    onSpinCompleteRef.current = onSpinComplete;
  }, [onSpinComplete]);

  // Layout mapping for 3x3 grid (Visual indices 0-8)
  // [0] [1] [2]
  // [7] [8] [3]
  // [6] [5] [4]
  const gridMapping = [
    { prizeIndex: 0, gridSlot: 0 }, // Top Left
    { prizeIndex: 1, gridSlot: 1 }, // Top Center
    { prizeIndex: 2, gridSlot: 2 }, // Top Right
    { prizeIndex: 3, gridSlot: 5 }, // Middle Right
    { prizeIndex: 4, gridSlot: 8 }, // Bottom Right
    { prizeIndex: 5, gridSlot: 7 }, // Bottom Center
    { prizeIndex: 6, gridSlot: 6 }, // Bottom Left
    { prizeIndex: 7, gridSlot: 3 }, // Middle Left
    { prizeIndex: 8, gridSlot: 4 }, // Center
  ];

  useEffect(() => {
    if (isSpinning && winnerIndex !== null) {
      const count = prizes.length;
      if (count === 0) return;

      const minLaps = 5; 
      const startIdx = activeIndex ?? 0;
      
      const distance = (winnerIndex - startIdx + count) % count;
      const totalSteps = (minLaps * count) + distance;
      
      let step = 0;
      
      const animate = () => {
        step++;
        const currentIdx = (startIdx + step) % count;
        setActiveIndex(currentIdx);

        if (step >= totalSteps) {
          timeoutRef.current = setTimeout(() => {
            if (onSpinCompleteRef.current) {
              onSpinCompleteRef.current();
            }
          }, 800);
          return;
        }

        const stepsRemaining = totalSteps - step;
        let delay = 50; 

        if (stepsRemaining < 15) {
            delay = 50 + (15 - stepsRemaining) * 25;
        }

        timeoutRef.current = setTimeout(animate, delay);
      };
      
      animate();
    }
    
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSpinning, winnerIndex, prizes.length]);

  const renderCell = (slotIndex: number) => {
    const mapItem = gridMapping.find(m => m.gridSlot === slotIndex);
    
    // Safety check if prize mapping exceeds current prizes
    if (!mapItem || !prizes[mapItem.prizeIndex]) {
        return <div key={slotIndex} className="bg-gray-800/30 rounded-xl"></div>;
    }

    const prize = prizes[mapItem.prizeIndex];
    const isActive = activeIndex === mapItem.prizeIndex;

    return (
      <div 
        key={slotIndex}
        className={`
          relative flex flex-col items-center justify-center text-center p-1 md:p-2 rounded-xl transition-all duration-100 border-2 overflow-hidden aspect-square select-none shadow-inner
          ${isActive 
            ? 'z-10 scale-105 shadow-[0_0_20px_rgba(255,255,255,0.5)] border-white' 
            : 'border-gray-700 opacity-90'
          }
        `}
        style={{
          backgroundColor: isActive ? prize.color : `${prize.color}20`,
          borderColor: isActive ? '#ffffff' : prize.color,
        }}
      >
        <div className="absolute top-1 left-1 md:top-2 md:left-2 text-[10px] md:text-xs font-bold bg-black/40 px-1.5 py-0.5 rounded text-white/80">
           {mapItem.prizeIndex + 1}
        </div>
        
        <div className="flex flex-col items-center justify-center w-full h-full p-1">
          <span 
            className={`font-bold text-xs md:text-sm line-clamp-3 leading-tight drop-shadow-md ${isActive ? 'text-white scale-110 transition-transform' : 'text-gray-100'}`}
            style={{ textShadow: '0 2px 4px rgba(0,0,0,0.8)' }}
          >
            {prize.label}
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-lg mx-auto p-4 perspective-1000 flex flex-col gap-6">
      <div className="grid grid-cols-3 gap-2 md:gap-3 bg-gray-900/50 p-3 rounded-3xl border border-gray-700 shadow-2xl backdrop-blur-sm">
        {[0, 1, 2, 3, 4, 5, 6, 7, 8].map(i => renderCell(i))}
      </div>

      <div className="w-full px-2">
         {canSpin ? (
             <button
              onClick={onSpinClick}
              disabled={isSpinning}
              className={`
                w-full py-4 rounded-2xl font-black text-xl md:text-2xl text-white shadow-lg transition-all transform active:scale-95 flex items-center justify-center gap-3
                ${isSpinning 
                    ? 'bg-gray-700 cursor-not-allowed opacity-50 shadow-none' 
                    : 'bg-gradient-to-r from-red-600 via-pink-600 to-red-600 hover:from-red-500 hover:via-pink-500 hover:to-red-500 shadow-[0_0_20px_rgba(239,68,68,0.4)] hover:shadow-[0_0_30px_rgba(239,68,68,0.6)]'
                }
              `}
            >
              {isSpinning ? (
                <>
                   <Sparkles className="animate-spin" />
                   <span>در حال چرخش...</span>
                </>
              ) : (
                <>
                  <Sparkles className="animate-pulse" />
                  <span>شانستو امتحان کن</span>
                  <Sparkles className="animate-pulse" />
                </>
              )}
            </button>
          ) : (
            <div className="w-full bg-gray-900/80 rounded-2xl border-2 border-gray-700 p-4 shadow-inner">
                <Countdown 
                    remainingMs={cooldownTime} 
                    onComplete={onCooldownComplete} 
                />
            </div>
          )}
      </div>
    </div>
  );
};

export default LuckyGrid;