import React from 'react';
import { Trophy, Users } from 'lucide-react';
import { Prize } from '../types';

interface Winner {
  id: number;
  name: string;
  prize: string;
  time: string;
  color: string;
}

interface RecentWinnersProps {
  winners: Winner[];
}

const RecentWinners: React.FC<RecentWinnersProps> = ({ winners }) => {
  return (
    <div className="w-full max-w-lg mx-auto mt-4 bg-gray-900/60 border border-gray-700 rounded-xl overflow-hidden backdrop-blur-sm">
      <div className="bg-gray-800/80 px-4 py-3 flex justify-between items-center border-b border-gray-700">
        <h3 className="font-bold text-sm text-gray-200 flex items-center gap-2">
          <Trophy size={16} className="text-yellow-500" />
          برندگان اخیر
        </h3>
        <span className="flex items-center gap-1 text-[10px] text-green-400 bg-green-900/30 px-2 py-1 rounded-full animate-pulse">
          <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
          Live
        </span>
      </div>
      
      <div className="divide-y divide-gray-800 max-h-40 overflow-y-auto">
        {winners.length === 0 ? (
          <div className="p-4 text-center text-xs text-gray-500">
            هنوز برنده ای ثبت نشده است
          </div>
        ) : (
          winners.map((winner) => (
            <div key={winner.id} className="px-4 py-3 flex justify-between items-center hover:bg-white/5 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center text-xs font-bold text-gray-300 border border-gray-600">
                   {winner.name.charAt(0)}
                </div>
                <div className="flex flex-col">
                  <span className="text-xs text-gray-400">{winner.name}</span>
                  <span className="text-sm font-bold text-white truncate max-w-[150px]" style={{ color: winner.color }}>
                    {winner.prize}
                  </span>
                </div>
              </div>
              <span className="text-[10px] text-gray-500 font-mono">{winner.time}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default RecentWinners;