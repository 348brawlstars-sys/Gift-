import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

interface CountdownProps {
  remainingMs: number;
  onComplete: () => void;
}

const Countdown: React.FC<CountdownProps> = ({ remainingMs, onComplete }) => {
  const [timeLeft, setTimeLeft] = useState(remainingMs);

  useEffect(() => {
    if (timeLeft <= 0) {
      onComplete();
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        const next = prev - 1000;
        if (next <= 0) {
          clearInterval(interval);
          onComplete();
          return 0;
        }
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [timeLeft, onComplete]);

  const hours = Math.floor((timeLeft / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((timeLeft / (1000 * 60)) % 60);
  const seconds = Math.floor((timeLeft / 1000) % 60);

  return (
    <div className="flex flex-col items-center justify-center text-center w-full">
      <Clock size={20} className="text-gray-400 mb-1" />
      <p className="text-[10px] md:text-xs text-gray-400 mb-1">شانس بعدی</p>
      <div className="text-lg md:text-xl font-mono font-bold text-red-400 tracking-wider">
        {String(hours).padStart(2, '0')}:{String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
      </div>
    </div>
  );
};

export default Countdown;