import React from 'react';
import { Prize } from '../types';
import { getCoordinatesForPercent } from '../utils/wheelUtils';

interface WheelProps {
  prizes: Prize[];
  rotation: number;
  isSpinning: boolean;
}

const Wheel: React.FC<WheelProps> = ({ prizes, rotation, isSpinning }) => {
  const numSegments = prizes.length;
  const radius = 200; // SVG coordinate system radius
  const center = 200; // Center point (200, 200)

  // Generate SVG paths for slices
  const slices = prizes.map((prize, index) => {
    const startAngle = index / numSegments;
    const endAngle = (index + 1) / numSegments;
    
    const [startX, startY] = getCoordinatesForPercent(startAngle);
    const [endX, endY] = getCoordinatesForPercent(endAngle);

    // Convert unit circle coords to SVG coords
    const x1 = center + radius * startX;
    const y1 = center + radius * startY;
    const x2 = center + radius * endX;
    const y2 = center + radius * endY;

    // SVG Path command
    // M = Move to center
    // L = Line to start
    // A = Arc to end
    // Z = Close path
    const pathData = `M ${center} ${center} L ${x1} ${y1} A ${radius} ${radius} 0 0 1 ${x2} ${y2} Z`;

    // Text position: mid-angle, slightly inwards
    const midAngle = (startAngle + endAngle) / 2;
    const [textXRaw, textYRaw] = getCoordinatesForPercent(midAngle);
    // Push text out about 65% of radius
    const textRadius = radius * 0.70;
    const textX = center + textRadius * textXRaw;
    const textY = center + textRadius * textYRaw;
    
    // Calculate rotation for text to be readable
    // Degrees: (midAngle * 360) + 90 to align radial text
    const rotateText = (midAngle * 360) + 90;

    return (
      <g key={prize.id}>
        <path 
          d={pathData} 
          fill={prize.color} 
          stroke="#1a1a2e" 
          strokeWidth="2"
        />
        <text
          x={textX}
          y={textY}
          fill="white"
          fontSize="12"
          fontWeight="bold"
          fontFamily="Vazirmatn"
          textAnchor="middle"
          alignmentBaseline="middle"
          transform={`rotate(${rotateText}, ${textX}, ${textY})`}
          className="drop-shadow-md pointer-events-none select-none"
        >
          {prize.label.length > 15 ? prize.label.substring(0, 12) + '...' : prize.label}
        </text>
      </g>
    );
  });

  return (
    <div className="relative w-80 h-80 md:w-96 md:h-96 mx-auto perspective-1000">
      {/* The Outer Rim */}
      <div className="absolute inset-0 rounded-full border-8 border-yellow-500 shadow-[0_0_20px_rgba(234,179,8,0.5)] z-10 pointer-events-none"></div>
      
      {/* The Indicator (Triangle) */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-4 z-20 w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-t-[30px] border-t-white drop-shadow-lg"></div>

      {/* The Spinning Wheel */}
      <div 
        className="w-full h-full rounded-full overflow-hidden transition-transform duration-[4000ms] cubic-bezier(0.2, 0.8, 0.2, 1)"
        style={{ transform: `rotate(${rotation}deg)` }}
      >
        <svg viewBox="0 0 400 400" className="w-full h-full transform -rotate-90">
          {slices}
        </svg>
      </div>
      
      {/* Center Cap */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-white rounded-full z-20 shadow-xl border-4 border-gray-800 flex items-center justify-center">
         <div className="w-2 h-2 bg-gray-800 rounded-full"></div>
      </div>
    </div>
  );
};

export default Wheel;
