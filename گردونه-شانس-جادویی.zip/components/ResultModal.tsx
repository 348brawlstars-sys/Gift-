import React from 'react';
import { Prize } from '../types';
import { TELEGRAM_ID } from '../constants';
import { Gift, ExternalLink } from 'lucide-react';

interface ResultModalProps {
  prize: Prize | null;
  isOpen: boolean;
  onClose: () => void;
}

const ResultModal: React.FC<ResultModalProps> = ({ prize, isOpen, onClose }) => {
  if (!isOpen || !prize) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/90 backdrop-blur-sm" onClick={onClose}></div>
      
      {/* Modal Content */}
      <div className="relative bg-gradient-to-br from-gray-900 to-gray-800 border border-yellow-500/30 w-full max-w-md rounded-3xl p-8 text-center shadow-2xl transform transition-all scale-100 animate-bounce">
        
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-yellow-500 p-4 rounded-full shadow-lg shadow-yellow-500/50">
           <Gift size={48} className="text-white animate-pulse" />
        </div>

        <h2 className="mt-8 text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-200 mb-2">
          تبریک!
        </h2>
        
        <p className="text-gray-300 mb-6">شما برنده شدید:</p>
        
        <div 
          className="py-4 px-6 rounded-xl mb-8 border-2 shadow-inner"
          style={{ 
            backgroundColor: `${prize.color}20`, 
            borderColor: prize.color,
            color: prize.color === '#ffffff' ? 'white' : prize.color
          }}
        >
          <p className="text-2xl font-bold shadow-black drop-shadow-md">{prize.label}</p>
        </div>

        <div className="bg-blue-600/10 border border-blue-500/30 rounded-xl p-4 mb-6">
          <p className="text-sm text-blue-200 mb-2">برای دریافت جایزه به آیدی زیر پیام دهید:</p>
          <a 
            href={`https://t.me/${TELEGRAM_ID.replace('@', '')}`} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 text-xl font-mono font-bold text-blue-400 hover:text-blue-300 transition-colors"
          >
            {TELEGRAM_ID}
            <ExternalLink size={16} />
          </a>
        </div>

        <button 
          onClick={onClose}
          className="w-full bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400 text-black font-bold py-3 rounded-xl shadow-lg transition-transform active:scale-95"
        >
          بستن و لذت بردن
        </button>
      </div>
    </div>
  );
};

export default ResultModal;