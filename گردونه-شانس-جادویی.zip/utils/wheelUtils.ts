import { Prize } from '../types';

/**
 * Calculates the X,Y coordinates on the circle circumference
 */
export const getCoordinatesForPercent = (percent: number) => {
  const x = Math.cos(2 * Math.PI * percent);
  const y = Math.sin(2 * Math.PI * percent);
  return [x, y];
};

/**
 * Selects a winner based on the weights of the prizes.
 * Returns the index of the winner.
 */
export const calculateWinnerIndex = (prizes: Prize[]): number => {
  const totalWeight = prizes.reduce((sum, prize) => sum + prize.weight, 0);
  if (totalWeight === 0) return Math.floor(Math.random() * prizes.length);

  let random = Math.random() * totalWeight;
  
  for (let i = 0; i < prizes.length; i++) {
    if (random < prizes[i].weight) {
      return i;
    }
    random -= prizes[i].weight;
  }
  return 0; // Fallback
};

/**
 * Check if the user is allowed to spin based on local storage
 */
export const checkCooldown = (): { allowed: boolean; remainingMs: number } => {
  const lastSpinStr = localStorage.getItem('lastSpinTime');
  if (!lastSpinStr) return { allowed: true, remainingMs: 0 };

  const lastSpin = parseInt(lastSpinStr, 10);
  
  // Safety check for invalid date
  if (isNaN(lastSpin)) {
     localStorage.removeItem('lastSpinTime');
     return { allowed: true, remainingMs: 0 };
  }

  const now = Date.now();
  const cooldownMs = 24 * 60 * 60 * 1000;
  const passed = now - lastSpin;

  if (passed >= cooldownMs) {
    return { allowed: true, remainingMs: 0 };
  }

  return { allowed: false, remainingMs: cooldownMs - passed };
};