import React, { useState, useEffect, useCallback } from 'react';
import LuckyGrid from './components/LuckyGrid';
import AdminPanel from './components/AdminPanel';
import ResultModal from './components/ResultModal';
import RecentWinners from './components/RecentWinners';
import { Settings, Users, Wifi } from 'lucide-react';
import { INITIAL_PRIZES, COOLDOWN_HOURS } from './constants';
import { Prize } from './types';
import { calculateWinnerIndex, checkCooldown } from './utils/wheelUtils';

// Simple confetti effect component
const Confetti = () => (
  <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden">
    {[...Array(50)].map((_, i) => (
      <div
        key={i}
        className="absolute w-2 h-2 bg-yellow-500 rounded-full animate-ping"
        style={{
          left: `${Math.random() * 100}%`,
          top: `${Math.random() * 100}%`,
          animationDuration: `${Math.random() * 2 + 1}s`,
          animationDelay: `${Math.random()}s`,
          backgroundColor: ['#EF4444', '#3B82F6', '#10B981', '#F59E0B', '#8B5CF6'][Math.floor(Math.random() * 5)]
        }}
      ></div>
    ))}
  </div>
);

// Fake user names for simulation
const FAKE_USERS = ['Ali_Gamer', 'King_M', 'Reza007', 'Sara.B', 'DarkWolf', 'Taha_X', 'Omid.Pro'];

export const App: React.FC = () => {
  const [prizes, setPrizes] = useState<Prize[]>(INITIAL_PRIZES);
  const [isSpinning, setIsSpinning] = useState(false);
  const [winnerIndex, setWinnerIndex] = useState<number | null>(null);
  const [winPrize, setWinPrize] = useState<Prize | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [cooldownTime, setCooldownTime] = useState(0);
  const [canSpin, setCanSpin] = useState(false);
  
  // New features state
  const [onlineUsers, setOnlineUsers] = useState(124);
  const [recentWinners, setRecentWinners] = useState<any[]>([
     { id: 1, name: 'Amir.H', prize: '40 میلیون تومان پول نقد', time: '12:30', color: '#8B5CF6' },
     { id: 2, name: 'Mona_99', prize: 'PS5', time: '12:15', color: '#3B82F6' },
  ]);

  // Initialize data on mount
  useEffect(() => {
    // Load prizes from local storage if they exist
    const savedPrizes = localStorage.getItem('wheelPrizes');
    if (savedPrizes) {
      try {
        const parsedPrizes = JSON.parse(savedPrizes);
        // Robust check: Ensure length matches and it is an array
        if (Array.isArray(parsedPrizes) && parsedPrizes.length === INITIAL_PRIZES.length) {
          setPrizes(parsedPrizes);
        } else {
          console.warn("Invalid prizes data in local storage, resetting.");
          setPrizes(INITIAL_PRIZES);
        }
      } catch (e) {
        console.error("Error parsing prizes", e);
        setPrizes(INITIAL_PRIZES);
      }
    }

    // Check cooldown
    const status = checkCooldown();
    if (status.allowed) {
      setCanSpin(true);
      setCooldownTime(0);
    } else {
      setCanSpin(false);
      setCooldownTime(status.remainingMs);
    }

    // Simulate online users changing
    const interval = setInterval(() => {
      setOnlineUsers(prev => Math.max(10, prev + Math.floor(Math.random() * 5) - 2));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleUpdatePrizes = (newPrizes: Prize[]) => {
    setPrizes(newPrizes);
    localStorage.setItem('wheelPrizes', JSON.stringify(newPrizes));
  };

  const handleResetCooldown = () => {
    localStorage.removeItem('lastSpinTime');
    setCanSpin(true);
    setCooldownTime(0);
  };

  const handleSpinClick = useCallback(() => {
    if (!canSpin || isSpinning) return;
    if (prizes.length === 0) return;

    // 1. Determine winner based on weights
    const winIdx = calculateWinnerIndex(prizes);
    if (winIdx >= 0 && winIdx < prizes.length) {
      setWinnerIndex(winIdx);
      setIsSpinning(true);
    } else {
      console.error("Invalid winner calculated");
    }
  }, [canSpin, isSpinning, prizes]);

  const handleSpinComplete = useCallback(() => {
    if (winnerIndex === null) return;
    
    setIsSpinning(false);
    const prize = prizes[winnerIndex];
    if (!prize) return; // Safety

    setWinPrize(prize);
    setShowResult(true);
    setWinnerIndex(null);

    // Save Timestamp
    const now = Date.now();
    localStorage.setItem('lastSpinTime', now.toString());
    setCanSpin(false);
    setCooldownTime(COOLDOWN_HOURS * 60 * 60 * 1000);

    // Add to recent winners
    const newWinner = {
      id: Date.now(),
      name: 'شما',
      prize: prize.label,
      time: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      color: prize.color
    };
    setRecentWinners(prev => [newWinner, ...prev].slice(0, 5));

  }, [winnerIndex, prizes]);

  return (
    <div className="min-h-screen bg-[#1a1a2e] flex flex-col items-center py-6 px-4 relative overflow-y-auto font-[Vazirmatn]">
      
      {/* Background Decor */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-20 z-0">
        <div className="absolute top-10 left-10 w-64 h-64 bg-purple-600 rounded-full blur-[100px]"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-600 rounded-full blur-[120px]"></div>
      </div>

      {showResult && <Confetti />}

      {/* Top Bar */}
      <div className="w-full max-w-lg flex justify-between items-center mb-6 z-10 px-2">
         {/* Admin Button - Now prominent */}
         <button 
           onClick={() => setShowAdmin(true)}
           className="flex items-center gap-2 bg-gray-800/80 hover:bg-gray-700 text-gray-300 px-3 py-1.5 rounded-lg border border-gray-600 transition-colors text-xs md:text-sm font-bold backdrop-blur-sm"
         >
            <Settings size={16} />
            پنل مدیریت
         </button>

         {/* Online Counter */}
         <div className="flex items-center gap-2 bg-gray-800/80 px-3 py-1.5 rounded-lg border border-gray-600 backdrop-blur-sm text-xs md:text-sm text-gray-300">
            <Wifi size={14} className="text-green-400" />
            <span className="font-mono font-bold text-white">{onlineUsers}</span>
            <span>آنلاین</span>
         </div>
      </div>

      {/* Header */}
      <header className="z-10 mb-4 text-center">
        <h1 className="text-3xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 drop-shadow-sm mb-2">
          جعبه شانس جادویی
        </h1>
        <p className="text-gray-400 text-sm md:text-base">شانس خود را برای برنده شدن یکی از ۹ جایزه نفیس امتحان کنید!</p>
      </header>

      {/* Main Game Area */}
      <div className="z-10 w-full mb-8">
        <LuckyGrid 
          prizes={prizes}
          isSpinning={isSpinning}
          winnerIndex={winnerIndex}
          onSpinComplete={handleSpinComplete}
          canSpin={canSpin}
          onSpinClick={handleSpinClick}
          cooldownTime={cooldownTime}
          onCooldownComplete={() => {
            setCanSpin(true);
            setCooldownTime(0);
          }}
        />
        
        {/* Recent Winners Feature */}
        <RecentWinners winners={recentWinners} />
      </div>

      {/* Modals */}
      <AdminPanel 
        isOpen={showAdmin} 
        onClose={() => setShowAdmin(false)} 
        prizes={prizes}
        onUpdatePrizes={handleUpdatePrizes}
        onResetCooldown={handleResetCooldown}
      />
      
      <ResultModal 
        isOpen={showResult} 
        prize={winPrize} 
        onClose={() => setShowResult(false)} 
      />

    </div>
  );
};