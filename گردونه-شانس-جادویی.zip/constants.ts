import { Prize } from './types';

export const ADMIN_PASSWORD = "1389";
export const TELEGRAM_ID = "@Seven646335";
export const COOLDOWN_HOURS = 24;

export const INITIAL_PRIZES: Prize[] = [
  { id: 1, label: "آیفون 17 پرو مکس", color: "#EF4444", weight: 10 },
  { id: 2, label: "PS5", color: "#3B82F6", weight: 15 },
  { id: 3, label: "ساعت هوشمند", color: "#10B981", weight: 20 },
  { id: 4, label: "ایکس باکس سری اس", color: "#F59E0B", weight: 15 },
  { id: 5, label: "40 میلیون تومان پول نقد", color: "#8B5CF6", weight: 5 },
  { id: 6, label: "ماشین 206 صفر کلیپ متر", color: "#EC4899", weight: 1 },
  { id: 7, label: "S25 الترا", color: "#14B8A6", weight: 5 },
  { id: 8, label: "پی سی گیمینگ علی سگ دست", color: "#F97316", weight: 5 },
  { id: 9, label: "طاها جنده", color: "#546E7A", weight: 5 },
];